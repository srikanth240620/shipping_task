{{-- <script src="{{url('/js/jquery.min.js')}}"></script> --}}
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="{{url('/js/main.js')}}"></script>

{{-- <script src="{{url('/js/jquery.slim.min.js')}}"></script> --}}
<script src="{{url('/js/popper.min.js')}}"></script>
<script src="{{url('/js/bootstrap.bundle.min.js')}}"></script>