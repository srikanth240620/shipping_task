@extends('layouts.main')

@section('style')

@stop

@section('content')  



 <div class="text-center pt-4 cart_empty_design">

@if (session('success'))
    <div class="alert alert-success alert-dismissible fade show ml-auto mr-auto" style="width: 600px" role="alert">
        {{ session('success') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif

@if (session('error'))
    <div class="alert alert-danger alert-dismissible fade show ml-auto mr-auto" style="width: 600px" role="alert">
        {{ session('error') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif


    <h4 class="mt-4 mb-3">Your Orders </h4>
 <div class='btn-holder'>
                        <a href="{{url('/')}}" class="hover-border-1 shadow m-0 text-center">
                            <span>Continue Shopping</span>
                        </a>
                    </div>
                    </div>


@php

$data = DB::table('order_product')->where('order_product.user_id',auth()->user()->id)
->join('order','order.id','=','order_product.order_id')
->select('order_product.*','order.status as order_status')
->orderby('order_product.id','desc')
->get();



@endphp




 <div class="container cart_hide">
            <table class="table">
                <thead>
                    <tr>
                        <th width="40%">PRODUCT</th>
                        <th width="20%">ORDER STATUS</th>
                        <th width="25%">SHIPPING STATUS</th>
                        <th width="15%" class="text-end">TOTAL AMOUNT</th>
                    </tr>
                </thead>
                <tbody>

                    @foreach($data as $k=>$val)

                    <tr class="remove_row_{{($k+1)}}">
                        <td>
                            <div class="d-flex">
                                <img src="{{$val->image}}"
                                    alt="" width="100" height="100">
                                <div class="ml-5">
                                    <a href="{{url('/products/'.Crypt::encryptString($val->product_id))}}" style="color:black;"><h5>{{$val->name}}</h5></a>
                                    <p class="m-0">Price - {{$val->price}}</p>
                                    <p class="m-0">Size - {{$val->size}}</p>
                                    <p class="m-0">Color - {{$val->color}}</p>
                                </div>
                            </div>
                        </td>

 <td>
                                @if($val->order_status==1)
                               <span class="text-success">Success</span>
                               @elseif($val->order_status==2)
                               <span class="text-danger">Failed</span>
                               @else
                               <span class="text-danger">Pending</span>
                               @endif

                        </td>


                        <td>
                                @if($val->status==1)
                               <span class="text-success">Success</span>
                               @elseif($val->status==2)
                               <span class="text-danger">Failed</span>
                               @else
                               <span class="text-danger">Pending</span>
                               @endif

                        </td>
                        <td class="text-end">
                            <div>Rs. <span class="total_sum_{{($k+1)}}">{{$val->total_amount}}</span></div>
                            <input type="hidden" name="total_amount[]" class="total_am_{{($k+1)}}" value="{{$val->total_amount}}">
                        </td>
                    </tr>

                    @endforeach


                </tbody>
            </table>
           
 </div>
            
          

       

         @endsection

    @section('script')


    <script>




function quantity_infor(type,key,id) {
    var q = parseInt($(".quantity_input_"+key).val()) || 0;

    var price = parseInt($(".price_input_"+key).val()) || 0;

    var value = 1;

    if (type == 'add') {
        value = q + 1;
    } else {
        if (q > 1) {
            value = q - 1;
        }
    }
    console.log(value);
    $(".quantity_input_"+key).val(value);
    $(".quantity_text_"+key).text(value);
    $(".total_sum_"+key).text((value * price));
    $(".total_am_"+key).val((value * price));

    // update_cart(key,'quantity',value)
    

total_amount();

update_cart(key,id,'quantity',value);
}

function total_amount(){
     let sum = 0;
       $('input[name="total_amount[]"]').each(function() {
            let val = parseFloat($(this).val()) || 0;
            sum += val;
        });

        console.log(sum);

        $('.full_total_amount').text(sum);
}




// Update cart

function update_cart(key,id,type,quantity){

    // var quantity='';
    // if(type=='quantity'){
    //    var quantity=quantity;
    // }
      $.ajax({
    url: '/update_cart',
      headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  },
    type: 'POST',
    data: {
        cart_id:id,
        type:type,
        quantity:quantity,

    },
    success: function(data) {
if(data.code==200){
    $(".cart_count").text(data.cart_count);

    if(type=="remove"){
    $(".remove_row_"+key).remove();

    var rowCount = $('table tbody tr').length;
    if(rowCount==0){
    $(".cart_empty_design").show();
    $(".cart_hide").hide();


    }


    }



}

    },
    error: function(xhr, status, error) {
      console.error('AJAX Error:', error);
    }
  });
}


    </script>

    @stop