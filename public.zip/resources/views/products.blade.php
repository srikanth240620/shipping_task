@extends('layouts.main')
@section('style')
@stop
@section('content')  
<div class="container mt-3">
   <div class="row">
      <div class="col-md-6">
         <div id='lens'></div>
         <div id='slideshow-items-container'>
            @foreach ($data->image as $k=>$img)
            <img class='slideshow-items @if($k===0) active @endif'
               src='{{$img}}'>
            @endforeach
         </div>
         <div id='result'></div>
         <div class=''>
            @foreach ($data->image as $k=>$img)
            <img class='slideshow-thumbnails @if($k===0) active @endif'
               src='{{$img}}'>
            @endforeach
         </div>
      </div>
      <div class="col-md-6">
         <h4>{{$data->name}}</h4>
         <p>{{$data->description}}</p>
         <form action="{{ url('/checkouts') }}" method="GET" class="">
         <input type="hidden" name="product_id" value="{{$data->encode}}">
         <input type="hidden" name="type" value="product">
         <div class="mb-3">
            <h2 class="h5 fw-semibold mb-3" style="font-size: 16px;">Size</h2>
            <div class="size-option d-flex">
               @foreach ($data->size as $k=>$v)
               <input type="radio" id="size-{{$k}}"  @if($k===0) checked @endif name="size" value="{{$v}}">
               <label for="size-{{$k}}">{{$v}}</label>
               @endforeach
            </div>
         </div>
         <div class="mb-3">
            <h2 class="h5 fw-semibold mb-3" style="font-size: 16px;">Color</h2>
            <div class="size-option d-flex">
               @foreach ($data->color as $k=>$v)
               <input type="radio" id="color-{{$k}}"  @if($k===0) checked @endif name="color" value="{{$v}}">
               <label for="color-{{$k}}" style="text-transform: capitalize;">{{$v}}</label>
               @endforeach
            </div>
         </div>
         <h2 class="h5 fw-semibold mb-3" style="font-size: 16px;">Quantity</h2>
         <div class="d-flex mt-3">
            <button id="btn-plus" type="button" class="btn btn-outline-dark" onclick="quantity_update('less')">
                <i class="fa fa-minus" aria-hidden="true"></i>
            </button>
            <span id="counter" class="ml-4 mr-4 quantity_text mt-auto mb-auto"
               style="font-size: 18px;">1</span>
            <input type="hidden" value="1" name="quantity" class="quantity_input">
            <button id="btn-minus" type="button" class="btn btn-outline-dark" onclick="quantity_update('add')">
                <i class="fa fa-plus" aria-hidden="true"></i>
                
            </button>
         </div>
         <h2 class="h5 fw-semibold mt-3" style="font-size: 16px;">Price</h2>
         <input type="hidden" name="price" class="price" value="{{$data->price}}">
         <span class="price_num">RS <span class="price_value">{{$data->price}}</span></span>
         <div class='btn-holder mt-5'>
            <button class="hover-border-1 shadow m-0 w-50 text-center" type="submit">
            <span>Buy Now</span>
            </button>
            {{-- <a href="#" class="hover-border-1 shadow">
            <span>Add to Cart</span>
            </a> --}}
         </div>
      </div>
   </div>

   <hr class="mt-5">
   {{-- product list --}}
<div class="row  pt-xl-5">


    @php
  $products=DB::table('products')
  ->where('id','!=',$data->id)
  ->where('status',1)->get();

  foreach ($products as $key => $value) {
    $image=json_decode($value->image);
    $value->img=$image[0]??"";
     $value->encode = Crypt::encryptString($value->id);
  }
        

    @endphp

    @foreach($products as $val)

   

            <div class="col-md-4">

                <div class="product-card">
                    <a href="{{url('products/'.$val->encode)}}" class="redirect_a_tag">
                        <div class="product-image-container">

                          
                            <img src="{{url('/'.$val->img)}}"
                                class="product-image" alt="Product">

                        </div>
                        <div class="product-info">
                            <h5 class="mt-2 mb-1">{{$val->name}}</h5>

                            <div class="product-price">

                                <span style="font-size: 18px; color: #28a745; font-weight: bold;" class="ml-2">RS
                                    {{$val->price}}</span>
                            </div>
                            {{-- <div class="product-icons">
                                <div class='btn-holder'>
                                    <button class="hover-border-1 shadow" onclick="add_cart(event,'{{$val->id}}')">
                                        <span>Add to cart</span>
                                    </button>
                                </div>
                            </div> --}}
                        </div>
                    </a>
                </div>

            </div>

             @endforeach

           

        </div>

   {{-- End product list --}}

</div>


 


@endsection
@section('script')
<script>

 $(document).ready(function () {
        // Thumbnail hover - change image
        $('.slideshow-thumbnails').hover(function () {
            changeSlide($(this));
        });

        // Mouse move to handle zoom
        $(document).mousemove(function (e) {
            var x = e.clientX;
            var y = e.clientY;

            var activeImg = $('.slideshow-items.active');
            var imgx1 = activeImg.offset().left;
            var imgx2 = activeImg.outerWidth() + imgx1;
            var imgy1 = activeImg.offset().top;
            var imgy2 = activeImg.outerHeight() + imgy1;

            if (x > imgx1 && x < imgx2 && y > imgy1 && y < imgy2) {
                $('#lens').show();
                $('#result').show();
                imageZoom(activeImg, $('#result'), $('#lens'));
            } else {
                $('#lens').hide();
                $('#result').hide();
            }
        });

        function changeSlide(elm) {
            $('.slideshow-items').removeClass('active');
            $('.slideshow-items').eq(elm.index()).addClass('active');
            $('.slideshow-thumbnails').removeClass('active');
            $('.slideshow-thumbnails').eq(elm.index()).addClass('active');
        }

        function imageZoom(img, result, lens) {
            result.width(img.innerWidth());
            result.height(img.innerHeight());
            lens.width(img.innerWidth() / 2);
            lens.height(img.innerHeight() / 2);

            result.offset({
                top: img.offset().top,
                left: img.offset().left + img.outerWidth() + 10
            });

            var cx = img.innerWidth() / lens.innerWidth();
            var cy = img.innerHeight() / lens.innerHeight();

            result.css('backgroundImage', 'url(' + img.attr('src') + ')');
            result.css('backgroundSize', (img.width() * cx) + 'px ' + (img.height() * cy) + 'px');

            lens.off('mousemove').on('mousemove', moveLens);
            img.off('mousemove').on('mousemove', moveLens);

            function moveLens(e) {
                var x = e.clientX - lens.outerWidth() / 2;
                var y = e.clientY - lens.outerHeight() / 2;

                var imgOffset = img.offset();
                var maxX = img.outerWidth() + imgOffset.left - lens.outerWidth();
                var maxY = img.outerHeight() + imgOffset.top - lens.outerHeight();

                if (x > maxX) x = maxX;
                if (x < imgOffset.left) x = imgOffset.left;
                if (y > maxY) y = maxY;
                if (y < imgOffset.top) y = imgOffset.top;

                lens.offset({ top: y, left: x });
                result.css('backgroundPosition', '-' + (x - imgOffset.left) * cx + 'px -' + (y - imgOffset.top) * cy + 'px');
            }
        }
    });
       
</script>
@stop