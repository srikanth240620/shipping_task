
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo e(url('/js/main.js')); ?>"></script>


<script src="<?php echo e(url('/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/bootstrap.bundle.min.js')); ?>"></script><?php /**PATH D:\srikanth\shopping\resources\views/includes/script.blade.php ENDPATH**/ ?>