 <link rel="stylesheet" href="<?php echo e(url('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/css/style.css')); ?>">
    
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" /><?php /**PATH D:\srikanth\shopping\resources\views/includes/style.blade.php ENDPATH**/ ?>