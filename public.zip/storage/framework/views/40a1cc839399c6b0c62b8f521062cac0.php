<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="icon" href="<?php echo e(url('/logo.png')); ?>" type="image/png" />


   
 <?php echo $__env->make('includes.style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body style="height: 100%" class="bg-light">


    <!-- Navbar -->
     <?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

      <!-- Navbar -->

  


    <div class="container-fluid ">

         <?php echo $__env->yieldContent('content'); ?>


    </div>




</body>
   <?php echo $__env->make('includes.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>



</html><?php /**PATH D:\srikanth\shopping\resources\views/layouts/main.blade.php ENDPATH**/ ?>