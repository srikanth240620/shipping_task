<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  
 <div class="">
   <div class="row">
      <div class="col-md-6 checkout_padding_left pt-4" style="background: white">
        <form id="myForm" method="post" action="<?php echo e(url('/checkouts_store')); ?>" class="needs-validation" novalidate>
         <?php echo csrf_field(); ?>
         <?php echo method_field('post'); ?>

<input type="hidden" name="product_id" value="<?php echo e(request('product_id')); ?>">
<input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
<input type="hidden" name="size" value="<?php echo e(request('size')); ?>">
<input type="hidden" name="color" value="<?php echo e(request('color')); ?>">
<input type="hidden" name="quantity" value="<?php echo e(request('quantity')); ?>">

         <div class="row">
            <div class="col-md-12 mt-2">
               <h5>Contact</h5>
            </div>
            <div class="col-md-12 mt-2">
               <input type="email" value="<?php echo e(auth()->user()->email); ?>" readonly class="form-control">
            </div>
            <div class="col-md-12 mt-2">
               <h5>Delivery</h5>
            </div>
            <div class="col-md-12 mt-2">
               <select name="country" class="form-control">
                  <option value="india">Indai</option>
               </select>
            </div>
            <div class="col-md-6 mt-2">
<input type="text"
           name="first_name" required
           value="<?php echo e(old('first_name')); ?>"
           class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>"
           placeholder="First Name">
            <div class="invalid-feedback"><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your first name.  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>               
            
            </div>
            <div class="col-md-6 mt-2">
               <input type="text" name="last_name" required value="<?php echo e(old('last_name')); ?>"
           class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" placeholder="Last Name">
               <div class="invalid-feedback"> <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your last name.  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                
            </div>
            <div class="col-md-12 mt-2">
               <textarea name="address" required cols="3" rows="4" 
           class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" placeholder="Address"><?php echo e(old('address')); ?></textarea>
               <div class="invalid-feedback"> <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your address.  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>
            <div class="col-md-12 mt-2">
               <input type="text" class="form-control" placeholder="Apartment, suite, etc. (optional)">
            </div>
            <div class="col-md-4 mt-2">
               <input type="text" name="city" required value="<?php echo e(old('city')); ?>" class="form-control <?php echo e($errors->has('city') ? 'is-invalid' : ''); ?>"  placeholder="City">
               <div class="invalid-feedback"> <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your city name.  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>
            <div class="col-md-4 mt-2">
               <select name="state" required class="form-control <?php echo e($errors->has('state') ? 'is-invalid' : ''); ?>">
        <option value="">Select</option>
        <option value="Andhra Pradesh" <?php echo e(old('state') == 'Andhra Pradesh' ? 'selected' : ''); ?>>Andhra Pradesh</option>
        <option value="Arunachal Pradesh" <?php echo e(old('state') == 'Arunachal Pradesh' ? 'selected' : ''); ?>>Arunachal Pradesh</option>
        <option value="Assam" <?php echo e(old('state') == 'Assam' ? 'selected' : ''); ?>>Assam</option>
        <option value="Bihar" <?php echo e(old('state') == 'Bihar' ? 'selected' : ''); ?>>Bihar</option>
        <option value="Chandigarh" <?php echo e(old('state') == 'Chandigarh' ? 'selected' : ''); ?>>Chandigarh</option>
        <option value="Chhattisgarh" <?php echo e(old('state') == 'Chhattisgarh' ? 'selected' : ''); ?>>Chhattisgarh</option>
        <option value="Dadra and Nagar Haveli" <?php echo e(old('state') == 'Dadra and Nagar Haveli' ? 'selected' : ''); ?>>Dadra and Nagar Haveli</option>
        <option value="Daman and Diu" <?php echo e(old('state') == 'Daman and Diu' ? 'selected' : ''); ?>>Daman and Diu</option>
        <option value="Delhi" <?php echo e(old('state') == 'Delhi' ? 'selected' : ''); ?>>Delhi</option>
        <option value="Goa" <?php echo e(old('state') == 'Goa' ? 'selected' : ''); ?>>Goa</option>
        <option value="Gujarat" <?php echo e(old('state') == 'Gujarat' ? 'selected' : ''); ?>>Gujarat</option>
        <option value="Haryana" <?php echo e(old('state') == 'Haryana' ? 'selected' : ''); ?>>Haryana</option>
        <option value="Himachal Pradesh" <?php echo e(old('state') == 'Himachal Pradesh' ? 'selected' : ''); ?>>Himachal Pradesh</option>
        <option value="Jammu and Kashmir" <?php echo e(old('state') == 'Jammu and Kashmir' ? 'selected' : ''); ?>>Jammu and Kashmir</option>
        <option value="Jharkhand" <?php echo e(old('state') == 'Jharkhand' ? 'selected' : ''); ?>>Jharkhand</option>
        <option value="Karnataka" <?php echo e(old('state') == 'Karnataka' ? 'selected' : ''); ?>>Karnataka</option>
        <option value="Kerala" <?php echo e(old('state') == 'Kerala' ? 'selected' : ''); ?>>Kerala</option>
        <option value="Ladakh" <?php echo e(old('state') == 'Ladakh' ? 'selected' : ''); ?>>Ladakh</option>
        <option value="Lakshadweep" <?php echo e(old('state') == 'Lakshadweep' ? 'selected' : ''); ?>>Lakshadweep</option>
        <option value="Madhya Pradesh" <?php echo e(old('state') == 'Madhya Pradesh' ? 'selected' : ''); ?>>Madhya Pradesh</option>
        <option value="Maharashtra" <?php echo e(old('state') == 'Maharashtra' ? 'selected' : ''); ?>>Maharashtra</option>
        <option value="Manipur" <?php echo e(old('state') == 'Manipur' ? 'selected' : ''); ?>>Manipur</option>
        <option value="Meghalaya" <?php echo e(old('state') == 'Meghalaya' ? 'selected' : ''); ?>>Meghalaya</option>
        <option value="Mizoram" <?php echo e(old('state') == 'Mizoram' ? 'selected' : ''); ?>>Mizoram</option>
        <option value="Nagaland" <?php echo e(old('state') == 'Nagaland' ? 'selected' : ''); ?>>Nagaland</option>
        <option value="Odisha" <?php echo e(old('state') == 'Odisha' ? 'selected' : ''); ?>>Odisha</option>
        <option value="Puducherry" <?php echo e(old('state') == 'Puducherry' ? 'selected' : ''); ?>>Puducherry</option>
        <option value="Punjab" <?php echo e(old('state') == 'Punjab' ? 'selected' : ''); ?>>Punjab</option>
        <option value="Rajasthan" <?php echo e(old('state') == 'Rajasthan' ? 'selected' : ''); ?>>Rajasthan</option>
        <option value="Sikkim" <?php echo e(old('state') == 'Sikkim' ? 'selected' : ''); ?>>Sikkim</option>
        <option value="Tamil Nadu" <?php echo e(old('state') == 'Tamil Nadu' ? 'selected' : ''); ?>>Tamil Nadu</option>
        <option value="Telangana" <?php echo e(old('state') == 'Telangana' ? 'selected' : ''); ?>>Telangana</option>
        <option value="Tripura" <?php echo e(old('state') == 'Tripura' ? 'selected' : ''); ?>>Tripura</option>
        <option value="Uttar Pradesh" <?php echo e(old('state') == 'Uttar Pradesh' ? 'selected' : ''); ?>>Uttar Pradesh</option>
        <option value="Uttarakhand" <?php echo e(old('state') == 'Uttarakhand' ? 'selected' : ''); ?>>Uttarakhand</option>
        <option value="West Bengal" <?php echo e(old('state') == 'West Bengal' ? 'selected' : ''); ?>>West Bengal</option>
    </select>
               <div class="invalid-feedback"> <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please select a state.  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>
            <div class="col-md-4 mt-2">
               <input type="text" name="pincode" required value="<?php echo e(old('pincode')); ?>" class="form-control <?php echo e($errors->has('pincode') ? 'is-invalid' : ''); ?>" placeholder="Pincode">
               <div class="invalid-feedback"> <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your Pincode.  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>
            <div class="col-md-12 mt-2">
               <input class="" type="checkbox" value="" id="flexCheckChecked">
               <label class="form-check-label" for="flexCheckChecked">
               Save this information for next time
               </label>
            </div>

             <div class="col-md-12 mt-2">
                <h5>Payment</h5>
                <p>All transactions are secure and encrypted.</p>
            </div>


<div class="col-md-12">
    <div class="row bg-light cart_border">
        <div class="col-md-12 d-flex justify-content-between cart_title"><div> Credit card </div> <img src="<?php echo e(url('/img/credit-card.png')); ?>" alt="Cart" width="25" height="25"></div>
         <div class="col-md-12 mt-2">
               <input type="text" name="cart_number" required value="<?php echo e(old('cart_number')); ?>" class="form-control <?php echo e($errors->has('cart_number') ? 'is-invalid' : ''); ?>" placeholder="Cart number" pattern="\d*"
       oninput="this.value = this.value.replace(/[^0-9]/g, '')" minlength="13" maxlength="19">
               <div class="invalid-feedback"> <?php $__errorArgs = ['cart_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your Cart number. <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>

             <div class="col-md-6 mt-2">
  <input type="text" id="expDate" name="expiration_date" required value="<?php echo e(old('expiration_date')); ?>" class="form-control <?php echo e($errors->has('expiration_date') ? 'is-invalid' : ''); ?>"  placeholder="MM / YY" maxlength="7">
               <div class="invalid-feedback"> <?php $__errorArgs = ['expiration_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?>  Please enter your expiration date. <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>

             <div class="col-md-6 mt-2">
               <input type="text" name="security_code" required value="<?php echo e(old('security_code')); ?>" class="form-control <?php echo e($errors->has('security_code') ? 'is-invalid' : ''); ?>" placeholder="Security code" pattern="\d*"
       oninput="this.value = this.value.replace(/[^0-9]/g, '')" required minlength="3" maxlength="4">
               <div class="invalid-feedback"> <?php $__errorArgs = ['security_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your Security code. <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>

             <div class="col-md-12 mt-2 mb-2">
               <input type="text" name="name_on_cart" required value="<?php echo e(old('name_on_cart')); ?>" class="form-control <?php echo e($errors->has('name_on_cart') ? 'is-invalid' : ''); ?>" placeholder="Name on cart">
               <div class="invalid-feedback"> <?php $__errorArgs = ['name_on_cart'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Please enter your Name on cart. <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>
    </div>
</div>


             <div class="col-md-12 mt-5 mb-5">
              <button class="btn btn-success w-100" type="submit"> Pay now</button>
            </div>
         </div>
        </form>
      </div>
         <div class="col-md-6 checkout_padding_right pt-4">

<div class="product_max_height pr-3">

   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex justify-content-between mt-2">
               <div class="position-relative mr-4" style="width:20%;">
                  <img src="<?php echo e($val->image); ?>" width="100" height="100" alt="" class="shadow-sm" style="border-radius: 10px;">
                  <span class="checkout_count"><?php echo e($val->quantity); ?></span>
               </div>
               <div class="mt-auto mb-auto" style="width:60%;">
                  <h6><?php echo e($val->name); ?></h5>
                  <p><?php echo e($val->size); ?> / <?php echo e($val->color); ?></p>
               </div>
               <h6 class="mt-auto mb-auto text-end" style="width:20%;">
               Rs. <?php echo e($val->total_amount); ?></h5>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        
         <hr class="mr-3">
         <div class="row pr-3">
            <div class="col-md-6">
               Subtotal
            </div>
            <div class="col-md-6 text-end">
               Rs. <?php echo e($total_amount); ?>

            </div>
            <div class="col-md-6 mt-2">
               Shipping
            </div>
            <div class="col-md-6 mt-2 text-end">
               Enter shipping address
            </div>
            <div class="col-md-6 mt-2">
               Estimated taxes
            </div>
            <div class="col-md-6 mt-2 text-end">
               Rs. 0
            </div>
            <div class="col-md-6 mt-3">
               <h5>Total</h5>
            </div>
            <div class="col-md-6 mt-3 text-end">
               <h5>Rs. <?php echo e($total_amount); ?></h5>
            </div>
         </div>
      </div>
   </div>
</div>



         <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>


    <script>




function quantity_infor(type,key) {
    var q = parseInt($(".quantity_input_"+key).val()) || 0;

    var price = parseInt($(".price_input_"+key).val()) || 0;

    var value = 1;

    if (type == 'add') {
        value = q + 1;
    } else {
        if (q > 1) {
            value = q - 1;
        }
    }
    console.log(value);
    $(".quantity_input_"+key).val(value);
    $(".quantity_text_"+key).text(value);
    $(".total_sum_"+key).text((value * price));
    $(".total_am_"+key).val((value * price));

total_amount();
}

function total_amount(){
     let sum = 0;
       $('input[name="total_amount[]"]').each(function() {
            let val = parseFloat($(this).val()) || 0;
            sum += val;
        });

        console.log(sum);

        $('.full_total_amount').text(sum);
}


// form validation
(function () {
      'use strict';
      window.addEventListener('load', function () {
        var form = document.getElementById('myForm');
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
          }
          form.classList.add('was-validated');
        }, false);
      }, false);
    })();


    document.getElementById('expDate').addEventListener('input', function (e) {
    let input = e.target.value;

    // Remove non-digits
    input = input.replace(/\D/g, '');

    // Format as MM / YY
    if (input.length >= 3) {
        input = input.slice(0, 2) + ' / ' + input.slice(2, 4);
    }

    e.target.value = input;
});

// Optional: prevent non-numeric input via keyboard
document.getElementById('expDate').addEventListener('keypress', function (e) {
    if (!/[0-9]/.test(e.key)) {
        e.preventDefault();
    }
});

    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\srikanth\shopping\resources\views/checkouts.blade.php ENDPATH**/ ?>