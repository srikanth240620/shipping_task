<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  

<?php if(request('search')): ?>
<div style="width: 405px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 23px;
    text-align:center;">
    <h5>Search results</h5>
<form action="/" method="get">
 <input type="text" class="form-control" name="search" placeholder="Search here..." id="searchInput" value="<?php echo e(request('search')); ?>" style="width:100%;">
<div class='btn-holder mb-0'>

                                    <button type="submit" class="hover-border-1 shadow text-center">
                                        <span>Search</span>
                                    </button>
                                    <a href="<?php echo e(url('/')); ?>" class="hover-border-1 shadow text-center">
                                        <span>Reset</span>
                                    </a>
                                </div>
                                </form>
                                </div>
                                <?php endif; ?>

<div class="row  pt-xl-5">


    <?php
$search=request('search');

  $products=DB::table('products')->where('status',1)->where('name', 'LIKE', '%' . $search . '%')->get();

  foreach ($products as $key => $value) {
    $image=json_decode($value->image);
    $value->image=$image;
    $value->img=url('/'.$image[0]??"");
     $value->encode = Crypt::encryptString($value->id);
 $value->size=json_decode($value->size);
  $value->color=json_decode($value->color);


  }
        

    ?>



    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   

            <div class="col-md-3">

                <div class="product-card">
                    <a href="<?php echo e(url('products/'.$val->encode)); ?>" class="redirect_a_tag">
                        <div class="product-image-container">

                          
                            <img src="<?php echo e($val->img); ?>"
                                class="product-image" alt="Product">

                        </div>
                        <div class="product-info">
                            <h5 class="mt-2 mb-1"><?php echo e($val->name); ?></h5>

                            <div class="product-price">

                                <span style="font-size: 18px; color: #28a745; font-weight: bold;" class="ml-2">RS
                                    <?php echo e($val->price); ?></span>
                            </div>
                            <div class="product-icons mb-0">
                                <div class='btn-holder'>

                                    <button class="hover-border-1 shadow m-0" <?php if(count($val->size)>1 || count($val->color)>1): ?> onclick="view_product(event,'<?php echo e(rawurlencode(json_encode($val))); ?>')" <?php else: ?> onclick="add_cart(event,'single','<?php echo e($val->id); ?>')" <?php endif; ?>>
                                        <span>Add to cart</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

            </div>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           

        </div>




<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="ProductDetails" tabindex="-1" role="dialog" aria-labelledby="ProductDetailsLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      
<div class="position-relative">
       <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="width: 30px;height: 30px;position: absolute;z-index: 10;right: 11px;top: 7px;">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>
      <div class="modal-body">


<div class="row">
 <div class="col-md-6">
         <div id='lens'></div>
         <div id='slideshow-items-container' class="production_top_images">
           
         </div>
         <div id='result'></div>
         <div class='production_bottom_images'>
          
         </div>
      </div>


      <div class="col-md-6">
         <h4 class="product_title_in" style="width: 92%"></h4>
         <p class="product_description_in"></p>
         <input type="hidden" name="product_id_in" value="" class="product_id_in" >
         <form action="<?php echo e(url('/checkouts')); ?>" method="GET" class="">
         <input type="hidden" name="product_id" value="" class="product_encode" >
         <input type="hidden" name="type" value="product">
         <div class="mb-3">
            <h2 class="h5 fw-semibold mb-3" style="font-size: 16px;">Size</h2>
            <div class="size-option d-flex size_details">
              
            </div>
         </div>
         <div class="mb-3">
            <h2 class="h5 fw-semibold mb-3" style="font-size: 16px;">Color</h2>
            <div class="size-option d-flex color_details">
              
            </div>
         </div>
         <h2 class="h5 fw-semibold mb-3" style="font-size: 16px;">Quantity</h2>
         <div class="d-flex mt-3">
           <button id="btn-minus" type="button" class="btn btn-outline-dark" onclick="quantity_update('less')"><i
               class="fa fa-minus" aria-hidden="true"></i>
            </button>
            <span id="counter" class="ml-4 mr-4 quantity_text mt-auto mb-auto"
               style="font-size: 18px;">1</span>
            <input type="hidden" value="1" name="quantity" class="quantity_input">
            <input type="hidden" value="" name="price" class="price">
            
 <button id="btn-plus" type="button" class="btn btn-outline-dark" onclick="quantity_update('add')"><i
               class="fa fa-plus" aria-hidden="true"></i>
            </button>

            
         </div>
         <h2 class="h5 fw-semibold mt-3" style="font-size: 16px;">Price</h2>
         <input type="hidden" name="price" class="product_price" value="">
         <span class="price_num">RS <span class="price_value"></span></span>
         <div class='btn-holder d-flex'>
             <button type="button" class="hover-border-1 shadow m-0 mr-5 text-center" onclick="add_cart(event,'multiple','0')">
            <span>Add to Cart</span>
            </button>
            <button class="hover-border-1 shadow m-0 text-center" type="submit">
            <span>Buy Now</span>
            </button>
           
         </div>
      </div>
   </div>


        
      </div>
      
    </div>
  </div>
</div>








        <div class="position-relative p-3 shadow rounded bg-white add_to_cart" style="display: none;">

<div class="d-flex justify-content-between">
    <div class="d-flex">
     <i class="fa fa-check mr-2 font-size: 21px; text-success" style="font-size: 22px;" aria-hidden="true"></i>
<div class="text-success">Item added to your cart</div>
</div>
<i class="fa fa-times close_cart" aria-hidden="true"></i>

</div>

<div class="d-flex mt-2">
    <img src="img/shopping.webp" width="100" height="100" alt="">
    <div class="pl-2">
        <h6> <b class="product_title"></b></h6>
        <div>Size: <span class="product_size"></span></div>
        <div>Color: <span class="product_color"></span></div>
    </div>
</div>

<div class='btn-holder mb-0'>
                                    <a href="<?php echo e(url('/cart')); ?>" class="hover-border-1 shadow w-75 text-center">
                                        <span>View cart</span>
                                    </a>

                                    <a href="<?php echo e(url('/checkouts')); ?>" class="hover-border-1 shadow w-75 text-center check_out_rul">
                                        <span>Check Out</span>
                                    </a>
                                </div>


        </div>
        


         <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>


<script>
    
function add_cart(event,type,id){
 event.stopPropagation();
    event.preventDefault();
    
    if(type=='multiple'){
   var data={
        product_id:$(".product_id_in").val(),
        color:$("input[name='color']:checked").val(),
        size:$("input[name='size']:checked").val(),
        quantity:$(".quantity_input").val(),

    }
    }else{
    var data={
         product_id:id,
    }
}

    var id=1;

     $.ajax({
    url: '/save_cart',
      headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  },
    type: 'POST',
    data: data,
    success: function(data) {
if(data.code==200){
    $(".cart_count").text(data.cart_count);


    if(type=='multiple'){
 var color= $("input[name='color']:checked").val();
      var size=$("input[name='size']:checked").val();
    }else{
      var color= data.data.color;
      var size=data.data.size;   

    }

$(".product_title").text(data.data.name);
$(".product_color").text(color);
$(".product_size").text(size);
// $(".check_out_rul").attr("href", data.data.encode);
$("#ProductDetails").modal('hide');
 $(".add_to_cart").css("display", "none").fadeIn(500).slideDown(500);

}

    },
    error: function(xhr, status, error) {
      console.error('AJAX Error:', error);
    }
  });
}



function view_product(event,encode){
 event.stopPropagation();
    event.preventDefault();

    var decodedString = decodeURIComponent(encode);
var jsonData = JSON.parse(decodedString);
console.log(jsonData);

$(".product_id_in").val(jsonData.id);
$(".product_encode").val(jsonData.encode);
$(".product_description_in").text(jsonData.description);
$(".product_title_in").text(jsonData.name);
$(".product_img_in").attr('src',jsonData.img);
$(".quantity_input").val(1);
$("#counter").text(1);
$(".price").val(jsonData.price);


$(".product_price").val(jsonData.price);
$(".price_value").text(jsonData.price);





// size


$(".size_details").html('');
$.each(jsonData.size, function(index, item) {
    var checked='';
    if(index == 0){
    var checked='checked';
    }
$(".size_details").append(`
 <input type="radio" id="size-`+index+`"  `+checked+` name="size" value="`+item+`">
               <label for="size-`+index+`">`+item+`</label>`);
});
// color 
$(".color_details").html('');
$.each(jsonData.color, function(index, item) {
    var checked='';
    if(index == 0){
    var checked='checked';
    }
$(".color_details").append(`
 <input type="radio" id="color-`+index+`"  `+checked+` name="color" value="`+item+`">
               <label for="color-`+index+`">`+item+`</label>`);
});

// images

$(".production_top_images").html('');
$(".production_bottom_images").html('');

$.each(jsonData.image, function(index, item) {
    var active='';
    if(index == 0){
    var active='active';
    }
$(".production_top_images").append(`
  <img class='slideshow-items `+active+`'
               src='`+item+`'>`);

               $(".production_bottom_images").append(`
  <img class='slideshow-thumbnails `+active+`'
               src='`+item+`'>`);
});

$("#ProductDetails").modal('show');


}


$(document).ready(function () {



    // Event delegation for thumbnails
    $(document).on('mouseenter', '.slideshow-thumbnails', function () {
        var index = $('.slideshow-thumbnails').index(this);
        changeSlide(index);
    });

    // Mouse move to handle zoom
    $(document).on('mousemove', function (e) {
        var activeImg = $('.slideshow-items.active');
        if (activeImg.length === 0) return;

        var imgx1 = activeImg.offset().left;
        var imgx2 = imgx1 + activeImg.outerWidth();
        var imgy1 = activeImg.offset().top;
        var imgy2 = imgy1 + activeImg.outerHeight();

        var x = e.clientX;
        var y = e.clientY;

        if (x > imgx1 && x < imgx2 && y > imgy1 && y < imgy2) {
            $('#lens').show();
            $('#result').show();
            imageZoom(activeImg, $('#result'), $('#lens'), x, y);
        } else {
            $('#lens').hide();
            $('#result').hide();
        }
    });

    function changeSlide(index) {
        $('.slideshow-items').removeClass('active');
        $('.slideshow-items').eq(index).addClass('active');
        $('.slideshow-thumbnails').removeClass('active');
        $('.slideshow-thumbnails').eq(index).addClass('active');
    }

    function imageZoom(img, result, lens, x, y) {
        result.width(img.innerWidth());
        result.height(img.innerHeight());
        lens.width(img.innerWidth() / 2);
        lens.height(img.innerHeight() / 2);

        result.offset({
            top: img.offset().top,
            left: img.offset().left + img.outerWidth() + 10
        });

        var cx = img.innerWidth() / lens.innerWidth();
        var cy = img.innerHeight() / lens.innerHeight();

        result.css('backgroundImage', 'url(' + img.attr('src') + ')');
        result.css('backgroundSize', (img.width() * cx) + 'px ' + (img.height() * cy) + 'px');

        var lensX = x - lens.outerWidth() / 2;
        var lensY = y - lens.outerHeight() / 2;

        var imgOffset = img.offset();
        var maxX = img.outerWidth() + imgOffset.left - lens.outerWidth();
        var maxY = img.outerHeight() + imgOffset.top - lens.outerHeight();

        if (lensX > maxX) lensX = maxX;
        if (lensX < imgOffset.left) lensX = imgOffset.left;
        if (lensY > maxY) lensY = maxY;
        if (lensY < imgOffset.top) lensY = imgOffset.top;

        lens.offset({ top: lensY, left: lensX });

        result.css('backgroundPosition', '-' + (lensX - imgOffset.left) * cx + 'px -' + (lensY - imgOffset.top) * cy + 'px');
    }
});



</script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\srikanth\shopping\resources\views/home.blade.php ENDPATH**/ ?>