<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  

<?php if(count($data)>0): ?>
 <div class="container cart_hide">
            <table class="table">
                <thead>
                    <tr>
                        <th width="60%">PRODUCT</th>
                        <th width="20%">QUANTITY</th>
                        <th width="20%" class="text-end">TOTAL</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="remove_row_<?php echo e(($k+1)); ?>">
                        <td>
                            <div class="d-flex">
                                <img src="<?php echo e($val->image); ?>"
                                    alt="" width="100" height="100">
                                <div class="ml-5">
                                    <a href="<?php echo e(url('/products/'.$val->encode)); ?>" style="color:black;"><h5><?php echo e($val->name); ?></h5></a>
                                    <p class="m-0">Price - <?php echo e($val->price); ?></p>
                                    <p class="m-0">Size - <?php echo e($val->size); ?></p>
                                    <p class="m-0">Color - <?php echo e($val->color); ?></p>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex">
                                <button id="btn-plus" class="btn btn-outline-dark" onclick="quantity_infor('add',<?php echo e(($k+1)); ?>,<?php echo e($val->id); ?>)"><i
                                        class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                                <span id="counter" class="ml-4 mr-4 quantity_text_<?php echo e(($k+1)); ?> mt-auto mb-auto"
                                    style="font-size: 18px;"><?php echo e($val->quantity); ?></span>
                                <input type="hidden" value="<?php echo e($val->quantity); ?>" name="quantity[]" class="quantity_input_<?php echo e(($k+1)); ?>">
                                <input type="hidden" value="<?php echo e($val->price); ?>" name="price[]" class="price_input_<?php echo e(($k+1)); ?>">

                                <button id="btn-minus" class="btn btn-outline-dark" onclick="quantity_infor('less',<?php echo e(($k+1)); ?>,<?php echo e($val->id); ?>)"><i
                                        class="fa fa-minus" aria-hidden="true"></i>
                                </button>
                                <i class="fa fa-trash cursor-pointer mb-auto ml-3 mt-auto" aria-hidden="true" onclick="update_cart('<?php echo e(($k+1)); ?>','<?php echo e($val->id); ?>','remove',0)"></i>
                            </div>

                        </td>
                        <td class="text-end">
                            <div>Rs. <span class="total_sum_<?php echo e(($k+1)); ?>"><?php echo e($val->total_amount); ?></span></div>
                            <input type="hidden" name="total_amount[]" class="total_am_<?php echo e(($k+1)); ?>" value="<?php echo e($val->total_amount); ?>">
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
            <hr>

            <div class="d-flex justify-content-end">
                <div class="width_checkout">
                    <h4>Estimated total Rs. <span class="full_total_amount"><?php echo e($total_amount); ?></span></h4>
                    <p>Taxes, discounts and shipping calculated at checkout.</p>
                    <div class='btn-holder'>
                        <a href="<?php echo e(url('checkouts')); ?>" class="hover-border-1 shadow m-0 text-center">
                            <span>Buy Now</span>
                        </a>
                    </div>
                </div>
            </div>
 </div>
              <?php endif; ?>
           
 <div class="text-center pt-4 cart_empty_design" <?php if(count($data)>0): ?> style="display: none" <?php endif; ?>>
    <h4 class="mt-4 mb-3">Your cart is empty</h4>
 <div class='btn-holder'>
                        <a href="<?php echo e(url('/')); ?>" class="hover-border-1 shadow m-0 text-center">
                            <span>Continue Shopping</span>
                        </a>
                    </div>
                    </div>

          

       

         <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>


    <script>




function quantity_infor(type,key,id) {
    var q = parseInt($(".quantity_input_"+key).val()) || 0;

    var price = parseInt($(".price_input_"+key).val()) || 0;

    var value = 1;

    if (type == 'add') {
        value = q + 1;
    } else {
        if (q > 1) {
            value = q - 1;
        }
    }
    console.log(value);
    $(".quantity_input_"+key).val(value);
    $(".quantity_text_"+key).text(value);
    $(".total_sum_"+key).text((value * price));
    $(".total_am_"+key).val((value * price));

    // update_cart(key,'quantity',value)
    

total_amount();

update_cart(key,id,'quantity',value);
}

function total_amount(){
     let sum = 0;
       $('input[name="total_amount[]"]').each(function() {
            let val = parseFloat($(this).val()) || 0;
            sum += val;
        });

        console.log(sum);

        $('.full_total_amount').text(sum);
}




// Update cart

function update_cart(key,id,type,quantity){

    // var quantity='';
    // if(type=='quantity'){
    //    var quantity=quantity;
    // }
      $.ajax({
    url: '/update_cart',
      headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  },
    type: 'POST',
    data: {
        cart_id:id,
        type:type,
        quantity:quantity,

    },
    success: function(data) {
if(data.code==200){
    $(".cart_count").text(data.cart_count);

    if(type=="remove"){
    $(".remove_row_"+key).remove();

    var rowCount = $('table tbody tr').length;
    if(rowCount==0){
    $(".cart_empty_design").show();
    $(".cart_hide").hide();


    }


    }



}

    },
    error: function(xhr, status, error) {
      console.error('AJAX Error:', error);
    }
  });
}


    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\srikanth\shopping\resources\views/cart.blade.php ENDPATH**/ ?>